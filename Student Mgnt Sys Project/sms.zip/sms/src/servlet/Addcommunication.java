package servlet;
import java.io.IOException;
import lookup.lookup;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.*;
import dao.daocommunication;

/**
 * Servlet implementation class AddCommunication
 */
@WebServlet("/Addcommunication")
public class Addcommunication extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addcommunication() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Message from the Server ").append(request.getContextPath());
		response.setContentType("text/html");	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String fn=request.getParameter("fn");
		int id=Integer.parseInt(request.getParameter("id"));
		//----------------getParameter
		//AddZ.java01 String COL=request.getParameter("COL");
		int type=Integer.parseInt(request.getParameter("type"));
		int from1=Integer.parseInt(request.getParameter("from1"));
		int to1=Integer.parseInt(request.getParameter("to1"));
		String subject=request.getParameter("subject");
		String message=request.getParameter("message");
		System.out.println("fn="+fn+" id="+id+" type="+type+" from1="+from1+" to1="+to1+" message="+message);

				
		try 
		{
			lookup l=lookup.getlookup();
			daocommunication dao=new daocommunication();
			System.out.println('\n'+fn+','+id
					//AddZ.java02 +','+COL
						+','+type
						+','+from1
						+','+to1
						+','+subject
						+','+message
			);
			int rv=dao.addCommunicationDetails(fn,id
					//AddZ.java03 ,COL
						,type
						,from1
						,to1
						,subject
						,message
				);
			 //request.getRequestDispatcher(l.tab).forward(request, response);
				PrintWriter out = response.getWriter();
				out.println("<HTML>");
				out.println("<TITLE>Data Information</TITLE>");
				out.println("<BODY ><CENTER><br/><br/><br/><br/>");
				if(rv==0)
				{

					out.println("<p><font color='green'>DATA INSERTED SUCCESSFULLY</p>");
					out.println("<button onclick=\"window.close();\">OK</a>");
				}
				else 
				{
					out.println("<p><font color='red'>DATA INSERT FAILED</p>");
					out.println("<a href=\"#\" onclick=\"location.href = document.referrer; return false;\">Back</a>");
				}
				
				out.println("</CENTER></BODY></HTML>");
		}
		catch(Exception e)
		{
			System.out.println("handling code "+e.getMessage());
			  
		}
	}
	

}
