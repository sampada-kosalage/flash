package servlet;
import java.io.IOException;
import lookup.lookup;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.daoschedule;

/**
 * Servlet implementation class Addschedule
 */
@WebServlet("/Addschedule")
public class Addschedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addschedule() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Message from the Server ").append(request.getContextPath());
		response.setContentType("text/html");	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String fn=request.getParameter("fn");
		String id=request.getParameter("id");
		//----------------getParameter
		//AddZ.java01 String COL=request.getParameter("COL");
		int course_id=Integer.parseInt(request.getParameter("course_id"));
		Date start_date =new Date();
		Date end_date=new Date();
		try {
			start_date = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("start_date"));
			end_date = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("end_date"));
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int location_id=Integer.parseInt(request.getParameter("location_id"));
		int faculty_id=Integer.parseInt(request.getParameter("faculty_id"));
		int batch_id=Integer.parseInt(request.getParameter("batch_id"));

				
		try 
		{
			lookup l=lookup.getlookup();
			daoschedule dao=new daoschedule();
			System.out.println('\n'+fn+','+id
					//AddZ.java02 +','+COL
						+','+course_id
						+','+start_date
						+','+end_date
						+','+location_id
						+','+faculty_id
						+','+batch_id
			);
			int rv=dao.addscheduleDetails(fn,Integer.parseInt(id)
					//AddZ.java03 ,COL
						,course_id
						,start_date
						,end_date
						,location_id
						,faculty_id
						,batch_id
				);
			 //request.getRequestDispatcher(l.tab).forward(request, response);
				PrintWriter out = response.getWriter();
				out.println("<HTML>");
				out.println("<TITLE>Data Information</TITLE>");
				out.println("<BODY ><CENTER><br/><br/><br/><br/>");
				if(rv==0)
				{

					out.println("<p><font color='green'>DATA INSERTED SUCCESSFULLY</p>");
					out.println("<button onclick=\"window.close();\">OK</a>");
				}
				else 
				{
					out.println("<p><font color='red'>DATA INSERT FAILED</p>");
					out.println("<a href=\"#\" onclick=\"location.href = document.referrer; return false;\">Back</a>");
				}
				
				out.println("</CENTER></BODY></HTML>");
		}
		catch(Exception e)
		{
			System.out.println("handling code "+e.getMessage());
			  
		}
	}
	

}
