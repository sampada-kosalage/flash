package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

import database.db;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int user_id=0;
		int user_type=0;
		Timestamp ts = null; 
		doGet(request, response);

		String username=request.getParameter("username");
		String password=request.getParameter("password");
		try {
			int norec;
			norec=db.select("select * from user where username='"+username+"'and password='"+password+"'");
			if(norec>0)
			{
				if(db.rs.next()){
					user_id=db.rs.getInt("id");
					user_type=db.rs.getShort("user_type");
					HttpSession session=request.getSession();
					session.setAttribute("user_id",db.rs.getInt("id"));
					session.setAttribute("username",db.rs.getString("username"));
					session.setAttribute("user_type",db.rs.getShort("user_type"));
					session.setAttribute("lastlogin",db.rs.getString("lastlogin"));
				    //Convert the time into UTC and build Timestamp object.
				    ts = Timestamp.valueOf(LocalDateTime.now(ZoneId.of("UTC")));
				    //use setTimestamp on preparedstatement
					db.update("update user set lastlogin='"+ts+"',nofailedlogin=0 where id="+user_id);
					String pg="";
					if(user_type==1)pg="Tabadmin.jsp";
					if(user_type==2)pg="Tabcounsellor.jsp";
					if(user_type==3)pg="Tabstudent.jsp";
					if(user_type==4)pg="Tabfaculty.jsp";
					RequestDispatcher rd=request.getRequestDispatcher(pg);
					rd.forward(request, response);
				}
			}
			else
			{
				norec=db.select("select * from user where username='"+username+"'");
				if(norec>0)
				{
					if(db.rs.next()){
						user_id=db.rs.getInt("id");
						db.update("update user set nofailedlogin=nofailedlogin+1 where id="+user_id);
					}
				}
				RequestDispatcher rd=request.getRequestDispatcher("loginpage.jsp");
				rd.forward(request, response);
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
