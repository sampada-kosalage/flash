package database;

public class validations {

}
