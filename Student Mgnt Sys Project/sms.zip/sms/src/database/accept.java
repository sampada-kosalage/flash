package database;
import java.util.Date;
public class accept {
	
	public static String institute_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select institute.id, institute.name institute_name from institute",var, "institute_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String location_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select location.id, location.name location_name from location",var, "location_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String venue_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select venue.id, venue.name venue_name from venue",var, "venue_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String user_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select user.id, user.username user_name from user",var, "user_name", cd, mndt);
		System.out.println(s);
		return(s);
	}
	public static String admin_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select admin.id, admin.name admin_name from admin",var, "admin_name", cd, mndt);
		System.out.println(s);
		return(s);
	}
	public static String counsellor_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select counsellor.id, counsellor.name counsellor_name from counsellor",var, "counsellor_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String batch_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select batch.id, batch.name batch_name from batch",var, "batch_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String course_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select course.id, course.name course_name from course",var, "course_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String subject_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select subject.id, subject.name subject_name from subject",var, "subject_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String topic_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select topic.id, topic.name topic_name from topic",var, "topic_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String student_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select student.id, student.name student_name from student",var, "student_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String faculty_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select faculty.id, faculty.name faculty_name from faculty",var, "faculty_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String batch_id1(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		//String s=dropdown.fromtable("select vbatch.id,CONCAT(batch_name,'-',course_name,'-',start_date,'-',end_date) batch_info from vbatch",var, "batch_info", cd,mndt);
		String s=dropdown.fromtable("select vbatch.id,vbatch.batch_info from vbatch",var, "batch_info", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String exam_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select exam.id, exam.name exam_name from exam",var, "exam_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String project_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select project.id, project.name project_name from project",var, "project_name", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String date(String var,Date value,int mndt)
	{
		String required="";
		if(mndt>0)required="Required";
	    String s="<input type=date name="+var+" placeholder=YYYY-MM-DD maxlength=10 value="+value+" "+required+">";
	    return(s);
	}
	public static String session_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select session.id,CONCAT(id,'-',date,'-',location_id,'-',venue_id,'-',start_time,'-',end_time,'-',course_id,'-',subject_id,'-',topic_id,'-',faculty_id,'-',batch_id)  session2 from session",var, "session2", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String session_id2(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select id,session session1 from vsession",var, "session1", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String session_id3(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select id,session session1 from vsession3",var, "session1", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String session_id4(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String sql="SELECT `session`.`id`,\r\n" + 
				"	CONCAT(\r\n" + 
				"    `session`.`date`,'-',\r\n" + 
				"    `location`.`name` ,'-',\r\n" + 
				"    `venue`.`name` ,'-',\r\n" + 
				"    `session`.`start_time`,'-',\r\n" + 
				"    `session`.`end_time`,'-',\r\n" + 
				"    `course`.`name` ,'-',\r\n" + 
				"    `subject`.`name` ,'-',\r\n" + 
				"    `topic`.`name` ,'-',\r\n" + 
				"    `faculty`.`name` ,'-',\r\n" + 
				"    `batch`.`name` ) session3\r\n" + 
				"FROM `session`,\r\n" + 
				"`location`,\r\n" + 
				"`venue`,\r\n" + 
				"`course`,\r\n" + 
				"`subject`,\r\n" + 
				"`topic`,\r\n" + 
				"`faculty`,\r\n" + 
				"`batch`\r\n" + 
				"WHERE\r\n" + 
				" `session`.`location_id`= `location`.`id`\r\n" + 
				" AND   `session`.`venue_id`= `venue`.`id`\r\n" + 
				" AND   `session`.`course_id`= `course`.`id`\r\n" + 
				" AND   `session`.`subject_id`= `subject`.`id`\r\n" + 
				" AND   `session`.`topic_id`= `topic`.`id`\r\n" + 
				" AND   `session`.`faculty_id`=`faculty`.`id`\r\n" + 
				" AND   `session`.`batch_id` =`batch`.`id`";
		String s=dropdown.fromtable(sql,var, "session3", cd,mndt);
		System.out.println(s);
		return(s);
	}
	public static String admission_id(String var,int cd,int mndt)
	{
		System.out.println(var+cd+mndt);
		String s=dropdown.fromtable("select id,id id from admission",var, "id", cd,mndt);
		System.out.println(s);
		return(s);
	}
	
}

