package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import lookup.lookup;


public class dropdown {
	public static Statement ddstmt;
	public static ResultSet ddrs;
	static ResultSet rs;
	
	
	public static void getdropdown()
	{
	  if (ddrs==null)
	  {	  
	      System.out.println("fetching lookup data");
	  	  try {
	  		  lookup.getdbcon();
	  		  ddstmt=lookup.con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
		      ddrs=ddstmt.executeQuery("select * from lookup");
		  	} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	}
	  public static int select(String sql)
	  {
		  int rowcount;
		  System.out.println(sql);
		  try 
		  {
			  db.getdbconn();
			  ddstmt=db.dbconn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			  rs=ddstmt.executeQuery(sql);
			  rs.last();
			  rowcount = rs.getRow();
			  System.out.println("rowcount="+rowcount);
			  rs.beforeFirst();
		  } 
		  catch (SQLException e) 
		  {
			e.printStackTrace();
			return -1;
		  }
		  return rowcount;
	  }
	public static String getSelecttag(String name,String type, int code) {
		String select ="";
		String selected="";
		getdropdown();
		select=select+ "<select name='"+name+"'>";
		try {
			ddrs.beforeFirst();
			while(ddrs.next())
			{
				if(!ddrs.getString("type").equals(type))continue;
				if(ddrs.getInt("icode")== code)selected="selected";
				//if(Integer.parseInt(ddrs.getString("icode"))== code)selected="selected";
				select=select+"<option value="+ddrs.getString("icode")+" "+selected+">"+ddrs.getString("value")+"</option>";
				selected="";
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		select = select+"</select>";
		//String placeholder="AddNew";
		//select = select+"<input type=text name="+descr+" placeholder="+placeholder+">";
		return select;
	}
	public static String getSelectMultitag(String name,String type, int[] code) {
		String select ="";
		String selected="";
		getdropdown();
		select=select+ "<select multiple name='"+name+"'>";
		try {
			ddrs.beforeFirst();
			while(ddrs.next())
			{
				if(!ddrs.getString("type").equals(type))continue;
				for(int i=0;i<code.length;i++)if(Integer.parseInt(ddrs.getString("icode"))== code[i])selected="selected";
				select=select+"<option value="+ddrs.getString("icode")+" "+selected+">"+ddrs.getString("value")+"</option>";
				selected="";
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		select = select+"</select>";
		//String placeholder="AddNew";
		//select = select+"<input type=text name="+descr+" placeholder="+placeholder+">";
		return select;
	}
	public static String getSelecttagTable(String name,String col, int id1,int mndt) {
		String select ="";
		String selected="";
		String required="";
		System.out.println(name+col+id1);
		if(mndt>0)required="required";
		select=select+ "<select name='"+name+"' "+required+">";
		try {
			rs.beforeFirst();
			while(rs.next())
			{
				if(rs.getInt("id")== id1)selected="selected";
				select=select+"<option value="+rs.getString("id")+" "+selected+">"+rs.getString(col)+"</option>";
				selected="";
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		select = select+"</select>";
		//String placeholder="AddNew";
		//select = select+"<input type=text name="+descr+" placeholder="+placeholder+">";
		return select;
	}
	public static String getValue(String type,int icode)
	{
		String svalue="";
		select("select *  from lookup where  type='"+type+"' and icode="+icode);
		try {
		while(rs.next())
		{
			svalue=(rs.getString("value"));
		}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return svalue;
	}
	public static String getValueTable(String table,String col,int id)
	{
		String svalue="";
		select("select *  from "+table+" where  id="+id);
		try {
				while(rs.next())
				{
					svalue=(rs.getString(col));
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return svalue;
	}
	public static String fromtable(String sql, String var, String col,int val,int mndt)
	{
		System.out.println(sql+var+col+val);
		dropdown.select(sql);
		String s=dropdown.getSelecttagTable(var,col, val,mndt);
		System.out.println(s);
		return(s);
	}
	public static String getValueTablevsession3(String table,String col,int id)
	{
		String svalue="";
		String sql="SELECT `session`.`id`,\r\n" + 
				"	CONCAT(\r\n" + 
				"    `session`.`date`,'-',\r\n" + 
				"    `location`.`name` ,'-',\r\n" + 
				"    `venue`.`name` ,'-',\r\n" + 
				"    `session`.`start_time`,'-',\r\n" + 
				"    `session`.`end_time`,'-',\r\n" + 
				"    `course`.`name` ,'-',\r\n" + 
				"    `subject`.`name` ,'-',\r\n" + 
				"    `topic`.`name` ,'-',\r\n" + 
				"    `faculty`.`name` ,'-',\r\n" + 
				"    `batch`.`name` ) session3\r\n" + 
				"FROM `session`,\r\n" + 
				"`location`,\r\n" + 
				"`venue`,\r\n" + 
				"`course`,\r\n" + 
				"`subject`,\r\n" + 
				"`topic`,\r\n" + 
				"`faculty`,\r\n" + 
				"`batch`\r\n" + 
				"WHERE\r\n" + 
				" `session`.`location_id`= `location`.`id`\r\n" + 
				" AND   `session`.`venue_id`= `venue`.`id`\r\n" + 
				" AND   `session`.`course_id`= `course`.`id`\r\n" + 
				" AND   `session`.`subject_id`= `subject`.`id`\r\n" + 
				" AND   `session`.`topic_id`= `topic`.`id`\r\n" + 
				" AND   `session`.`faculty_id`=`faculty`.`id`\r\n" + 
				" AND   `session`.`batch_id` =`batch`.`id`" +
				" AND   `session`.`id` ="+id;
		select(sql);
		try {
				while(rs.next())
				{
					svalue=(rs.getString("session3"));
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return svalue;
	}
	
}
