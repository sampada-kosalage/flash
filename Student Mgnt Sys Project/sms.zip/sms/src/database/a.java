package database;

import java.sql.ResultSet;

import lookup.lookup;

public class a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			a vc= new a();
			vc.cst1();

	}
	public void cst1() {
		String sql;
		lookup l=lookup.getlookup();
		int i=0,j=0,k=0,m=0;
		int[][][][] cst = new int[100][100][100][100];
		String s="";

		try{
		sql="select * from coursesubjecttopic";
		// FILTER  ----------->
		sql=sql+" order by 1,2,3";
		l.getrs1(sql);
		ResultSet rscst=l.rs;
			while (rscst.next()) {
							s="";
							cst[i][j][k][m++]=rscst.getInt("id");
							s=s+cst[i][j][k][m];
							cst[i][j][k][m]=rscst.getInt("course_id");
							s=s+cst[i][j][k][m];
							cst[i][j][k][m]=rscst.getInt("subject_id");
							s=s+cst[i][j][k][m];
							cst[i][j][k][m]=rscst.getInt("topic_id");
							s=s+cst[i][j][k][m]+"\n";
							System.out.println(s);

			}
		}catch(Exception e)		{
			System.out.println(e);	
		}
		
	}

}
