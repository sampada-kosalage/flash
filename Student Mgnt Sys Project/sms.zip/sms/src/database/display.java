package database;

public class display {
	public static String admin_id(int id)
	{
		String s=dropdown.getValueTable("admin","name",id);
		return(s);
	}
	public static String counsellor_id(int id)
	{
		String s=dropdown.getValueTable("counsellor","name",id);
		return(s);
	}
	public static String course_id(int id)
	{
		String s=dropdown.getValueTable("course","name",id);
		return(s);
	}
	public static String subject_id(int id)
	{
		String s=dropdown.getValueTable("subject","name",id);
		return(s);
	}
	public static String topic_id(int id)
	{
		String s=dropdown.getValueTable("topic","name",id);
		return(s);
	}
	public static String user_id(int id)
	{
		String s=dropdown.getValueTable("user","username",id);
		return(s);
	}
	public static String student_id(int id)
	{
		String s=dropdown.getValueTable("student","name",id);
		return(s);
	}
	public static String location_id(int id)
	{
		String s=dropdown.getValueTable("location","name",id);
		return(s);
	}
	public static String batch_id(int id)
	{
		String s=dropdown.getValueTable("batch","name",id);
		return(s);
	}
	public static String batch_id1(int id)
	{
		
		String s=dropdown.getValueTable("vbatch","batch_info",id);
		System.out.println(s);
		return(s);
	}
	public static String faculty_id(int id)
	{
		String s=dropdown.getValueTable("faculty","name",id);
		return(s);
	}
	public static String venue_id(int id)
	{
		String s=dropdown.getValueTable("venue","name",id);
		return(s);
	}
	public static String session_id(int id)
	{
		String s=dropdown.getValueTablevsession3("vsession3","session3",id);
		return(s);
	}

}
