package database;

import java.sql.ResultSet;
import lookup.lookup;

public class viewcourse {




	

/*
	
	public String course() {
		String sql;
		String and;
		String s;
		lookup l=lookup.getlookup();

		//String scourseid = request.getParameter("courseid");
		String scourseid="0";
		int courseid=Integer.parseInt(scourseid);

		try{

		sql="select * from course";
		if(courseid==0)sql="select course.* from course";
		else sql="select course.* from course where course.id="+courseid;

		and="";
		// FILTER  ----------->
		sql=sql+" order by 1";
		l.getrs1(sql);
		ResultSet rsc=l.rs;
			while (rsc.next()) {
							s=rsc.getString("id");
							s=s+rsc.getString("name");
							s=s+rsc.getString("description");
							s=s+rsc.getInt("hours");
							s=s+rsc.getInt("fees");
							s=s+rsc.getString("logo");
							System.out.println(s);
							viewsubject();
							return null;
			}
		}

	}
*/
}
