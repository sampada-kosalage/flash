package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "counsell_student")
public class counsell_student {
	private int id
				,counsell_by_id;

	private String
	//pojoZ.java01 COL,
			dttm
			,name
			,requirement
			,interest_area
			,suggested_course
			,expected_joining
			,mobile
			,email
			,address
			,education
			,more_info


;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDttm() {
		return dttm;
	}

	public void setDttm(String dttm) {
		this.dttm = dttm;
	}

	public int getcounsell_by_id() {
		return counsell_by_id;
	}

	public void setcounsell_by_id(int counsell_by_id) {
		this.counsell_by_id = counsell_by_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getInterest_area() {
		return interest_area;
	}

	public void setInterest_area(String interest_area) {
		this.interest_area = interest_area;
	}

	public String getSuggested_course() {
		return suggested_course;
	}

	public void setSuggested_course(String suggested_course) {
		this.suggested_course = suggested_course;
	}

	public String getExpected_joining() {
		return expected_joining;
	}

	public void setExpected_joining(String expected_joining) {
		this.expected_joining = expected_joining;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getMore_info() {
		return more_info;
	}

	public void setMore_info(String more_info) {
		this.more_info = more_info;
	}

//Setters and Getters

}
