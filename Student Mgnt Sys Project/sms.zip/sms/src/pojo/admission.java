package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

import java.sql.Timestamp;
import java.util.*;

@Entity
@Table(name = "admission")
public class admission {
	private int id
				,student_id
				,course_id
				,admission_by
				,location_id
				,counsellor_id;
	private Short payment_type;
	private double fees_charged
				,fees_paid
				,fees_balance
				,discount;
	private String
	//pojoZ.java01 COL,
				referral
				,asn_no;
	private Date date_of_admission;
	private Timestamp	dttm;



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public Date getDate_of_admission() {
		return date_of_admission;
	}

	public void setDate_of_admission(Date date_of_admission) {
		this.date_of_admission = date_of_admission;
	}

	public int getAdmission_by() {
		return admission_by;
	}

	public void setAdmission_by(int admission_by) {
		this.admission_by = admission_by;
	}

	public double getFees_charged() {
		return fees_charged;
	}

	public void setFees_charged(double fees_charged) {
		this.fees_charged = fees_charged;
	}

	public double getFees_paid() {
		return fees_paid;
	}

	public void setFees_paid(double fees_paid) {
		this.fees_paid = fees_paid;
	}

	public double getFees_balance() {
		return fees_balance;
	}

	public void setFees_balance(double fees_balance) {
		this.fees_balance = fees_balance;
	}

	public Short getPayment_type() {
		return payment_type;
	}

	public void setPayment_type(Short payment_type) {
		this.payment_type = payment_type;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public String getReferral() {
		return referral;
	}

	public void setReferral(String referral) {
		this.referral = referral;
	}

	public String getAsn_no() {
		return asn_no;
	}

	public void setAsn_no(String asn_no) {
		this.asn_no = asn_no;
	}

	public int getLocation_id() {
		return location_id;
	}

	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}

	public int getcounsellor_id() {
		return counsellor_id;
	}

	public void setcounsellor_id(int counsellor_id) {
		this.counsellor_id = counsellor_id;
	}

	public Timestamp getDttm() {
		return dttm;
	}

	public void setDttm(Timestamp dttm) {
		this.dttm = dttm;
	}

//Setters and Getters

}
