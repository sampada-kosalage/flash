package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "question_bank")
public class question_bank {
	private int id
				,course_id
				,subject_id
				,topic_id
				,set_id;
	private short
				complexcity
				,answer_time;

	private String
	//pojoZ.java01 COL,
			
			question
			,a
			,b
			,c
			,d
			,correct
;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getSubject_id() {
		return subject_id;
	}

	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}

	public int getTopic_id() {
		return topic_id;
	}

	public void setTopic_id(int topic_id) {
		this.topic_id = topic_id;
	}

	public int getSet_id() {
		return set_id;
	}

	public void setSet_id(int set_id) {
		this.set_id = set_id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public String getB() {
		return b;
	}

	public void setB(String b) {
		this.b = b;
	}

	public String getC() {
		return c;
	}

	public void setC(String c) {
		this.c = c;
	}

	public String getD() {
		return d;
	}

	public void setD(String d) {
		this.d = d;
	}

	public String getCorrect() {
		return correct;
	}

	public void setCorrect(String correct) {
		this.correct = correct;
	}

	public int getComplexcity() {
		return complexcity;
	}

	public void setComplexcity(short complexcity) {
		this.complexcity = complexcity;
	}

	public short getAnswer_time() {
		return answer_time;
	}

	public void setAnswer_time(short answer_time) {
		this.answer_time = answer_time;
	}

//Setters and Getters

}
