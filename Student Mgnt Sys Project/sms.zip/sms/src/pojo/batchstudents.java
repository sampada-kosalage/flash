package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "batchstudents")
public class batchstudents {
	private int id
			,batch_id
			,student_id;

;
	//Setters and Getters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBatch_id() {
		return batch_id;
	}

	public void setBatch_id(int batch_id) {
		this.batch_id = batch_id;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}



}
