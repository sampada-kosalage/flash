package pojo;

import javax.persistence.Entity;
import java.util.Date;
import javax.persistence.Table;

@Entity
@Table(name = "batch")
public class batch {
	private int id
				,course_id;

	private String name;
	//pojoZ.java01 COL,
	private Date
			start_date
			,end_date

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

//Setters and Getters

}
