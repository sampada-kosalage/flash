package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "coursesubjecttopic")
public class coursesubjecttopic {
	private int id
	//pojoZ.java01 COL,
			,course_id
			,subject_id
			,topic_id;

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getSubject_id() {
		return subject_id;
	}

	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}

	public int getTopic_id() {
		return topic_id;
	}

	public void setTopic_id(int topic_id) {
		this.topic_id = topic_id;
	}

//Setters and Getters

}
