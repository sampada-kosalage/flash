package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "feedback")
public class feedback {
	private int id
			,level;

	private String
	//pojoZ.java01 COL,
			from1
			,for1
			,type
			,suggestion
			,comment
			,dttm;



;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDttm() {
		return dttm;
	}

	public void setDttm(String dttm) {
		this.dttm = dttm;
	}

	public String getFrom1() {
		return from1;
	}

	public void setFrom1(String from1) {
		this.from1 = from1;
	}

	public String getFor1() {
		return for1;
	}

	public void setFor1(String for1) {
		this.for1 = for1;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}



//Setters and Getters

}
