package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "exam")
public class exam {
	private int id
				,student_id
				,course_id
				,subject_id
				,topic_id;

	
	private short type
					,marks;
	private String
	//pojoZ.java01 COL,
			dttm

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public short getType() {
		return type;
	}

	public void setType(short type) {
		this.type = type;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

	public int getCourse_id() {
		return course_id;
	}

	public void setCourse_id(int course_id) {
		this.course_id = course_id;
	}

	public int getSubject_id() {
		return subject_id;
	}

	public void setSubject_id(int subject_id) {
		this.subject_id = subject_id;
	}

	public int getTopic_id() {
		return topic_id;
	}

	public void setTopic_id(int topic_id) {
		this.topic_id = topic_id;
	}

	public short getMarks() {
		return marks;
	}

	public void setMarks(short marks) {
		this.marks = marks;
	}

	public String getDttm() {
		return dttm;
	}

	public void setDttm(String dttm) {
		this.dttm = dttm;
	}

//Setters and Getters

}
