package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "documents")
public class documents {
	private int id;

	private String
	//pojoZ.java01 COL,
			bytype
			,typeid
			,docname
			,document

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBytype() {
		return bytype;
	}

	public void setBytype(String bytype) {
		this.bytype = bytype;
	}

	public String getTypeid() {
		return typeid;
	}

	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}

	public String getDocname() {
		return docname;
	}

	public void setDocname(String docname) {
		this.docname = docname;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

//Setters and Getters

}
