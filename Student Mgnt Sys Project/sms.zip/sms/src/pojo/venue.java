package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "venue")
public class venue {
	private int id
				,location_id;
	
	private short type;

	private String
	//pojoZ.java01 COL,
			name
			,details
;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLocation_id() {
		return location_id;
	}

	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}

	public short getType() {
		return type;
	}

	public void setType(short type) {
		this.type = type;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

//Setters and Getters

}
