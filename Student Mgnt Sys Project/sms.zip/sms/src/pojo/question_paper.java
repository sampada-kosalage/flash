package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "question_paper")
public class question_paper {
	private int id;

	private String
	//pojoZ.java01 COL,
			set_id
			,total_number_of_question
			,number_of_questions_to_answer
			,question
			,marks
			,answer
			,allocated_time

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSet_id() {
		return set_id;
	}

	public void setSet_id(String set_id) {
		this.set_id = set_id;
	}

	public String getTotal_number_of_question() {
		return total_number_of_question;
	}

	public void setTotal_number_of_question(String total_number_of_question) {
		this.total_number_of_question = total_number_of_question;
	}

	public String getNumber_of_questions_to_answer() {
		return number_of_questions_to_answer;
	}

	public void setNumber_of_questions_to_answer(String number_of_questions_to_answer) {
		this.number_of_questions_to_answer = number_of_questions_to_answer;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getMarks() {
		return marks;
	}

	public void setMarks(String marks) {
		this.marks = marks;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getAllocated_time() {
		return allocated_time;
	}

	public void setAllocated_time(String allocated_time) {
		this.allocated_time = allocated_time;
	}

//Setters and Getters

}
