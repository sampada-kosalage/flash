package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "topic")
public class topic {
	private int id
				,hours;

	private String
	//pojoZ.java01 COL,
			name
			,description
;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

//Setters and Getters

}
