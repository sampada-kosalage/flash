package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "location")
public class location {
	private int id;

	private String
	//pojoZ.java01 COL,
			name
			,facility
			,address
			,contact_person
			,phone_number
			,classrooms
			,labs
			,details

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFacility() {
		return facility;
	}

	public void setFacility(String facility) {
		this.facility = facility;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_person() {
		return contact_person;
	}

	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getClassrooms() {
		return classrooms;
	}

	public void setClassrooms(String classrooms) {
		this.classrooms = classrooms;
	}

	public String getLabs() {
		return labs;
	}

	public void setLabs(String labs) {
		this.labs = labs;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

//Setters and Getters

}
