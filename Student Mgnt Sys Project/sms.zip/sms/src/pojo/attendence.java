package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "attendence")
public class attendence {
	private int id

	//pojoZ.java01 COL,
	,session_id
	,student_id

;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSession_id() {
		return session_id;
	}

	public void setSession_id(int session_id) {
		this.session_id = session_id;
	}

	public int getStudent_id() {
		return student_id;
	}

	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}

//Setters and Getters

}
