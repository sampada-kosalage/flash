package pojo;

import javax.persistence.Entity;
import javax.persistence.Table;

import java.sql.Timestamp;
import java.util.*;

@Entity
@Table(name = "communication")
public class communication {
	private int id,
			//pojoZ.java01 COL,
			type
			,from1
			,to1;
	private String
			subject
			,message;
	private Timestamp
			dttm
;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getFrom1() {
		return from1;
	}

	public void setFrom1(int from1) {
		this.from1 = from1;
	}

	public int getTo1() {
		return to1;
	}

	public void setTo1(int to1) {
		this.to1 = to1;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Timestamp getDttm() {
		return dttm;
	}

	public void setDttm(Timestamp dttm) {
		this.dttm = dttm;
	}

//Setters and Getters

}
