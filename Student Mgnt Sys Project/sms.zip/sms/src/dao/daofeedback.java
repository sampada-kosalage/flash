package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.feedback;

public class daofeedback {


	public int addfeedbackDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String from1
		,String for1
		,String type
		,String suggestion
		,String comment
		,int level
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL

					+','+from1
					+','+for1
					+','+type
					+','+suggestion
					+','+comment
					+','+level
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			feedback r = new feedback();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);

			r.setFrom1(from1);
			r.setFor1(for1);
			r.setType(type);
			r.setSuggestion(suggestion);
			r.setComment(comment);
			r.setLevel(level);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
