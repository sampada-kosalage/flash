package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.certificate;
import java.util.Date;
public class daocertificate {


	public int addcertificateDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int student_id
		,int course_id
		,String grade
		,Date date
		,String performance
		,String comments
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+student_id
					+','+course_id
					+','+grade
					+','+date
					+','+performance
					+','+comments
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			certificate r = new certificate();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setStudent_id(student_id);
			r.setCourse_id(course_id);
			r.setGrade(grade);
			r.setDate(date);
			r.setPerformance(performance);
			r.setComments(comments);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
