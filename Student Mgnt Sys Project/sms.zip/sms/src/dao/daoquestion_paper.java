package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.question_paper;

public class daoquestion_paper {


	public int addquestion_paperDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String set_id
		,String total_number_of_question
		,String number_of_questions_to_answer
		,String question
		,String marks
		,String answer
		,String allocated_time
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+set_id
					+','+total_number_of_question
					+','+number_of_questions_to_answer
					+','+question
					+','+marks
					+','+answer
					+','+allocated_time
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			question_paper r = new question_paper();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setSet_id(set_id);
			r.setTotal_number_of_question(total_number_of_question);
			r.setNumber_of_questions_to_answer(number_of_questions_to_answer);
			r.setQuestion(question);
			r.setMarks(marks);
			r.setAnswer(answer);
			r.setAllocated_time(allocated_time);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
