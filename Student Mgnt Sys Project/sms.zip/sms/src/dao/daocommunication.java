package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;

import pojo.communication;
import database.db;
public class daocommunication {


	public int addCommunicationDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int type
		,int from1
		,int to1
		,String subject
		,String message
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+type
					+','+from1
					+','+to1
					+','+subject
					+','+message
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			communication r = new communication();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setType(type);
			r.setFrom1(from1);
			r.setTo1(to1);
			r.setSubject(subject);
			r.setMessage(message);

			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		/*String sql;
		sql="insert into communication(type,from1,to1,message) values("+type+","+from1+","+to1+",'"+message+"')";
		success=db.insert(sql);*/
		return(success);
	}
}
