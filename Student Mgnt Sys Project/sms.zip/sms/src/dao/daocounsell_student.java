package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.counsell_student;

public class daocounsell_student {


	public int addcounsell_studentDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String dttm
		,int counsell_by_id
		,String name
		,String requirement
		,String interest_area
		,String suggested_course
		,String expected_joining
		,String mobile
		,String email
		,String address
		,String education
		,String more_info
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+dttm
					+','+counsell_by_id
					+','+name
					+','+requirement
					+','+interest_area
					+','+suggested_course
					+','+expected_joining
					+','+mobile
					+','+email
					+','+address
					+','+education
					+','+more_info
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			counsell_student r = new counsell_student();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setDttm(dttm);
			r.setcounsell_by_id(counsell_by_id);
			r.setName(name);
			r.setRequirement(requirement);
			r.setInterest_area(interest_area);
			r.setSuggested_course(suggested_course);
			r.setExpected_joining(expected_joining);
			r.setMobile(mobile);
			r.setEmail(email);
			r.setAddress(address);
			r.setEducation(education);
			r.setMore_info(more_info);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
