package dao;
import java.util.Date;
import java.sql.Timestamp;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.admission;

public class daoadmission {


	public int addadmissionDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int student_id
		,int course_id
		,Date date_of_admission
		,int admission_by
		,double fees_charged
		,double fees_paid
		,double fees_balance
		,Short payment_type
		,double discount
		,String referral
		,String asn_no
		,int location_id
		,int counsellor_id
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+student_id
					+','+course_id
					+','+date_of_admission
					+','+admission_by
					+','+fees_charged
					+','+fees_paid
					+','+fees_balance
					+','+payment_type
					+','+discount
					+','+referral
					+','+asn_no
					+','+location_id
					+','+counsellor_id

		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			admission r = new admission();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setStudent_id(student_id);
			r.setCourse_id(course_id);
			r.setDate_of_admission(date_of_admission);
			r.setAdmission_by(admission_by);
			r.setFees_charged(fees_charged);
			r.setFees_paid(fees_paid);
			r.setFees_balance(fees_balance);
			r.setPayment_type(payment_type);
			r.setDiscount(discount);
			r.setReferral(referral);
			r.setAsn_no(asn_no);
			r.setLocation_id(location_id);
			r.setcounsellor_id(counsellor_id);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
