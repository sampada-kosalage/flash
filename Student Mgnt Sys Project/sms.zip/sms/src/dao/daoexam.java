package dao;

import java.sql.Timestamp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.exam;

public class daoexam {


	public int addexamDetails(String fn,int id
		//daoZ.java01 ,String COL
		,short type
		,int student_id
		,int course_id
		,int subject_id
		,int topic_id
		,short marks
		,String dttm
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+type
					+','+student_id
					+','+course_id
					+','+subject_id
					+','+topic_id
					+','+marks
					+','+dttm
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			exam r = new exam();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setType(type);
			r.setStudent_id(student_id);
			r.setCourse_id(course_id);
			r.setSubject_id(subject_id);
			r.setTopic_id(topic_id);
			r.setMarks(marks);
			r.setDttm(dttm);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
