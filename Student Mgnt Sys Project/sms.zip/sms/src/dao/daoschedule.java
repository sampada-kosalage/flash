package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.schedule;
import java.util.Date;
public class daoschedule {


	public int addscheduleDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int course_id
		,Date start_date
		,Date end_date
		,int location_id
		,int faculty_id
		,int batch_id
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+course_id
					+','+start_date
					+','+end_date
					+','+location_id
					+','+faculty_id
					+','+batch_id
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			schedule r = new schedule();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setCourse_id(course_id);
			r.setStart_date(start_date);
			r.setEnd_date(end_date);
			r.setLocation_id(location_id);
			r.setFaculty_id(faculty_id);
			r.setBatch_id(batch_id);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
