package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.transaction;

public class daotransaction {


	public int addtransactionsDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int admission_id
		,int student_id
		,short type
		,double amount
		,String receipt
		,double balance
		,String narration
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+admission_id
					+','+student_id
					+','+type
					+','+amount
					+','+receipt
					+','+balance
					+','+narration
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			transaction r = new transaction();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setAdmission_id(admission_id);
			r.setStudent_id(student_id);
			r.setType(type);
			r.setAmount(amount);
			r.setReceipt(receipt);
			r.setBalance(balance);
			r.setNarration(narration);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
