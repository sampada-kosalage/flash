package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.question_bank;

public class daoquestion_bank {


	public int addquestion_bankDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int course_id
		,int subject_id
		,int topic_id
		,int set_id
		,String question
		,String a
		,String b
		,String c
		,String d
		,String correct
		,Short complexcity
		,Short answer_time
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+course_id
					+','+subject_id
					+','+topic_id
					+','+set_id
					+','+question
					+','+a
					+','+b
					+','+c
					+','+d
					+','+correct
					+','+complexcity
					+','+answer_time
		);
		try 
		{
			Configuration c1=new Configuration();
			SessionFactory sf=c1.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			question_bank r = new question_bank();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setCourse_id(course_id);
			r.setSubject_id(subject_id);
			r.setTopic_id(topic_id);
			r.setSet_id(set_id);
			r.setQuestion(question);
			r.setA(a);
			r.setB(b);
			r.setC(c);
			r.setD(d);
			r.setCorrect(correct);
			r.setComplexcity(complexcity);
			r.setAnswer_time(answer_time);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
