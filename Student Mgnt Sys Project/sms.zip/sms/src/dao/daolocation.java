package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.location;

public class daolocation {


	public int addlocationDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String name
		,String facility
		,String address
		,String contact_person
		,String phone_number
		,String classrooms
		,String labs
		,String details
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+name
					+','+facility
					+','+address
					+','+contact_person
					+','+phone_number
					+','+classrooms
					+','+labs
					+','+details
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			location r = new location();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setName(name);
			r.setFacility(facility);
			r.setAddress(address);
			r.setContact_person(contact_person);
			r.setPhone_number(phone_number);
			r.setClassrooms(classrooms);
			r.setLabs(labs);
			r.setDetails(details);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
