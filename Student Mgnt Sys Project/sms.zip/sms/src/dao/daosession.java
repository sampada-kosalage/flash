package dao;

import java.sql.Time;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.session;

public class daosession {


	public int addsessionDetails(String fn,int id
		//daoZ.java01 ,String COL
		,Date date
		,int location_id
		,int venue_id
		,String start_time
		,String end_time
		,int course_id
		,int subject_id
		,int topic_id
		,int faculty_id
		,int batch_id
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+date
					+','+location_id
					+','+venue_id
					+','+start_time
					+','+end_time
					+','+course_id
					+','+subject_id
					+','+topic_id
					+','+faculty_id
					+','+batch_id
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			session r = new session();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setDate(date);
			r.setLocation_id(location_id);
			r.setVenue_id(venue_id);
			r.setStart_time(start_time);
			r.setEnd_time(end_time);
			r.setCourse_id(course_id);
			r.setSubject_id(subject_id);
			r.setTopic_id(topic_id);
			r.setFaculty_id(faculty_id);
			r.setBatch_id(batch_id);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
