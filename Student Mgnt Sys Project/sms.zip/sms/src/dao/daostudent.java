package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.student;

public class daostudent {


	public int addstudentDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String name
		,String education
		,String mobile
		,String email
		,String address
		,String username
		,String password
		,Short status
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+name
					+','+education
					+','+mobile
					+','+email
					+','+address
					+','+username
					+','+password
					+','+status
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			student r = new student();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setName(name);
			r.setEducation(education);
			r.setMobile(mobile);
			r.setEmail(email);
			r.setAddress(address);
			r.setUsername(username);
			r.setPassword(password);
			r.setStatus(status);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
