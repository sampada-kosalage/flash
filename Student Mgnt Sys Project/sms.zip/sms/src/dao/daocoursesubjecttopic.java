package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.coursesubjecttopic;

public class daocoursesubjecttopic {


	public int addcoursesubjecttopicDetails(String fn,int id
		//daoZ.java01 ,String COL
		,int course_id
		,int subject_id
		,int topic_id
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+course_id
					+','+subject_id
					+','+topic_id
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			coursesubjecttopic r = new coursesubjecttopic();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setCourse_id(course_id);
			r.setSubject_id(subject_id);
			r.setTopic_id(topic_id);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
