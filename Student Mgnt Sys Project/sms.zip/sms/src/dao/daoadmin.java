package dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pojo.admin;

public class daoadmin {


	public int addadminDetails(String fn,int id
		//daoZ.java01 ,String COL
		,String name
		,String mobile
		,String email
		,short  type
		,String username
		,String password
		,short status
	)
	{
		int success=-1;
		System.out.println('\n'+fn+','+id
			//daoZ.java02 +','+COL
					+','+name
					+','+mobile
					+','+email
					+','+type
					+','+username
					+','+password
					+','+status
		);
		try 
		{
			Configuration c=new Configuration();
			SessionFactory sf=c.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction tr=s.beginTransaction();
			
			admin r = new admin();
			// ----------Setters
			r.setId(id);
			//daoZ.java03 r.setCOL(COL);
			r.setName(name);
			r.setMobile(mobile);
			r.setEmail(email);
			r.setType(type);
			r.setUsername(username);
			r.setPassword(password);
			r.setStatus(status);
			
			if(fn.equals("Add"))
				id = (Integer)s.save(r);
			else
				s.update(r);
			tr.commit();
			sf.close();
			success=0;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			success=-1;
		}
		return(success);
	}
}
