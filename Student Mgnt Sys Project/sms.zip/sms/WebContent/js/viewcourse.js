/**
 * 
 */
function clickcourse1(courseid) {
	alert("in clickcourse="+courseid);
  var xhttp1 = new XMLHttpRequest();
  xhttp1.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("viewsubject").innerHTML = this.responseText;
     document.getElementById("viewtopic").innerHTML = "";
    }
  };
  xhttp1.open("GET", "Viewsubject.jsp?courseid="+courseid, true);
  xhttp1.send();
}
function clicksubject1(courseid,subjectid) {
	alert("in clicksubject="+courseid+"-"+subjectid);
  var xhttp2 = new XMLHttpRequest();
  xhttp2.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById("viewtopic").innerHTML = this.responseText;
    }
  };

  xhttp2.open("GET", "Viewtopic.jsp?courseid="+courseid+"&subjectid="+subjectid, true);
  xhttp2.send();
}
function clickx(xid,div,url) {
	//alert("in clickx="+xid);
  var xhttp1 = new XMLHttpRequest();
  xhttp1.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById(div).innerHTML = this.responseText;
    }
  };
  xhttp1.open("GET", url, true);
  xhttp1.send();
}
function clicky(yid,xid,div,url) {
	//alert("in clicky="+yid+"-"+xid);
  var xhttp1 = new XMLHttpRequest();
  xhttp1.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
     document.getElementById(div).innerHTML = this.responseText;
    }
  };
  xhttp1.open("GET", url, true);
  xhttp1.send();
}