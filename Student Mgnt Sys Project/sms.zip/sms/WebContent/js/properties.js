<!--  script src="http://code.jquery.com/jquery-latest.min.js"></script-->
//import "js/jquery-3.6.0.js";

var p=
{
  dbDriver:"com.mysql.jdbc.Driver",
  dbURL:"jdbc:mysql://localhost:3306/sms",
  dbUSER:"root",
  dbPWD:"root"	
}
function send_properties()
{
	var param="dbDriver="+p.dbDriver+"&"+"dbURL="+p.dbURL+"&"+"dbUSER="+p.dbUSER+"&"+"dbPWD="+p.dbPWD;
	$.post("dbProperties",param,alert("dbProperties received by server"));
}

