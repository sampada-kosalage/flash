# Grocery_ManagementSystem
An Online Grocery Management System where the Admin can Add, Update and Delete products. The Groceries are divided into various Categories like Fruits, Vegetables, Chocolates, etc. A user can select a particular item to view the details, choose the number he/she would like to order and fill in his/her details like Name, Address, etc to buy a product.

Used HTML, CSS, Java Server Pages and MySQL as database.
