package org.study.maven;

public @interface GetController {

	String value();

}
