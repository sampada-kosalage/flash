package onlinegroceryshopping.model;

public class SelectProduct extends Groceries{

	public SelectProduct(String product_name, String prod_img, String product_desc, double product_price, int cat_id) {
		super(product_name, prod_img, product_desc, product_price, cat_id);
	}

}
